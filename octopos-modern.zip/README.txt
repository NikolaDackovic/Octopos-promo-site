OCTOPOS MODULI — REDIZAJN

1. Postavite index.html, styles.css, app.js, modules.js i favicon.ico na server.
2. Za postojeće slike zadržite folder assets/images/ sa 4.jpg, 5.jpg i 6.jpg
   (u dostavljenim fajlovima slike nisu bile priložene).
3. Za YouTube/Vimeo video otvorite modules.js, pronađite željeni modul
   i upišite pun HTTPS URL u polje "videoUrl" (primer: https://www.youtube.com/watch?v=VIDEO_ID).
   Dugme za video će automatski biti prikazano kada je link validan.
4. Modul možete izmeniti u modules.js: tekst, kategoriju, niz slika i videoUrl.
5. Kontakt trenutno koristi email: podrska@octopos.rs.
6. Podaci 128 porudžbina i 24 aktivna stola na ilustraciji su dekorativni,
   ne predstavljaju stvarnu statistiku.
7. Pokretanje: otvorite index.html u pregledaču. Nije potreban server niti build.

NAPOMENA: originalni favicon.ico je priložen. Originalni logo octopos-logo.png
i slike 4.jpg, 5.jpg i 6.jpg nisu dostavljeni — kada dodate slike u assets/images/,
one se automatski prikazuju u modulu Order display.
