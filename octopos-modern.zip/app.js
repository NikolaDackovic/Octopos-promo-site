
const modules = window.OCTOPOS_MODULES;
const icons = {
monitor:'<rect x="3" y="4" width="18" height="14" rx="2"/><path d="M8 22h8M12 18v4M7 9h10M7 13h6"/>',
scan:'<path d="M4 9V5a2 2 0 0 1 2-2h3M15 3h3a2 2 0 0 1 2 2v4M20 15v3a2 2 0 0 1-2 2h-3M9 20H6a2 2 0 0 1-2-2v-3"/><rect x="8" y="8" width="8" height="8" rx="1"/><path d="M10 12h4"/>',
qr:'<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><path d="M14 14h3v3h-3zM20 14v3M14 21h3M20 20v1"/>',
smartphone:'<rect x="7" y="2" width="10" height="20" rx="2"/><path d="M11 18h2M10 5h4"/>',
ticket:'<path d="M3 7a2 2 0 0 0 2-2h14v4a2 2 0 0 0 0 4v4H5a2 2 0 0 0-2-2zM12 5v12" stroke-dasharray="3 2"/>',
chart:'<path d="M3 3v18h18M7 16l4-5 3 2 5-7"/><circle cx="19" cy="6" r="1"/>',
layers:'<path d="m12 3 9 5-9 5-9-5 9-5zM3 12l9 5 9-5M3 16l9 5 9-5"/>',
receipt:'<path d="M5 3h14v18l-3-2-4 2-4-2-3 2V3zM8 8h8M8 12h8M8 16h4"/>',
code:'<path d="m8 7-5 5 5 5m8-10 5 5-5 5M14 4l-4 16"/>',
hotel:'<path d="M3 21V7l9-4 9 4v14M3 21h18M9 21v-6h6v6M7 10h1m8 0h1"/>',
network:'<rect x="9" y="2" width="6" height="6" rx="1"/><rect x="2" y="16" width="6" height="6" rx="1"/><rect x="16" y="16" width="6" height="6" rx="1"/><path d="M12 8v4M5 16v-4h14v4"/>'
};
const svg=name=>`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${icons[name]||icons.layers}</svg>`;
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const grid=document.getElementById('module-grid'),search=document.getElementById('search'),counter=document.getElementById('shown-count');
let active='Svi';
const filters=['Svi','Operativa','Samousluga','Digitalna prodaja','Mobilnost','Analitika','Integracije'];
document.getElementById('filters').innerHTML=filters.map((f,i)=>`<button type="button" class="filter ${i===0?'active':''}" data-filter="${esc(f)}" aria-pressed="${i===0}">${esc(f)}</button>`).join('');
document.getElementById('filters').addEventListener('click',e=>{const b=e.target.closest('[data-filter]');if(!b)return;active=b.dataset.filter;document.querySelectorAll('.filter').forEach(x=>{x.classList.toggle('active',x===b);x.setAttribute('aria-pressed',String(x===b))});render();});
search.addEventListener('input',render);
const observer=new IntersectionObserver(entries=>entries.forEach(e=>{if(e.isIntersecting){e.target.classList.add('visible');observer.unobserve(e.target)}}),{threshold:.07});
function render(){
const query=search.value.toLocaleLowerCase('sr').trim();
const found=modules.filter(m=>(active==='Svi'||m.category===active)&&[m.title,m.intro,m.tag,m.purpose,...m.gains].join(' ').toLocaleLowerCase('sr').includes(query));
counter.textContent=found.length;
grid.innerHTML=found.length?found.map((m,i)=>`<article class="module reveal" style="transition-delay:${Math.min(i%3,2)*70}ms">
<div class="module-media ${m.images.length?'has-image':''}">${m.images.length?`<img src="${esc(m.images[0])}" alt="${esc(m.title)}" loading="lazy" onerror="this.style.display='none';this.nextElementSibling.style.display='grid'"><div class="art-icon" style="display:none">${svg(m.icon)}</div>`:`<div class="art-icon">${svg(m.icon)}</div>`}<span class="media-number">${String(m.id).padStart(2,'0')} / 11</span></div>
<div class="module-body"><span class="pill">${esc(m.tag)}</span><h3>${esc(m.title)}</h3><p class="module-desc">${esc(m.intro)}</p><div class="module-bottom"><button type="button" data-open="${m.id}" aria-label="Detalji: ${esc(m.title)}">Istraži modul <span aria-hidden="true">↗</span></button><span class="mod-arrow" aria-hidden="true">→</span></div></div></article>`).join(''):'<div class="empty">Nema modula za zadatu pretragu. Pokušajte sa drugim pojmom.</div>';
grid.querySelectorAll('.reveal').forEach(el=>observer.observe(el));
}
grid.addEventListener('click',e=>{const b=e.target.closest('[data-open]');if(b)openModule(Number(b.dataset.open))});
const modal=document.getElementById('details'),modalContent=document.getElementById('modal-content');let lastFocus;
function openModule(id){
const m=modules.find(x=>x.id===id);if(!m)return;
lastFocus=document.activeElement;
const benefits=m.benefits.map(b=>`<div class="benefit"><strong>${esc(b.title)}</strong><p>${esc(b.text)}</p></div>`).join('');
const gallery=m.images.length?`<section class="gallery"><h3>Galerija modula</h3><div class="gallery-grid">${m.images.map(src=>`<button type="button" data-image="${esc(src)}" aria-label="Uvećaj sliku"><img src="${esc(src)}" loading="lazy" alt="${esc(m.title)}"/></button>`).join('')}</div></section>`:'';
const video=/^https:\/\/(www\.)?(youtube\.com|youtu\.be|vimeo\.com)\//i.test(m.videoUrl||'')?`<a class="video-link" href="${esc(m.videoUrl)}" target="_blank" rel="noopener noreferrer">▶ Pogledajte video demonstraciju ↗</a>`:'';
modalContent.innerHTML=`<div class="modal-head"><span class="eyebrow">${esc(m.tag)}</span><h2>${esc(m.title)}</h2><p>${esc(m.intro)}</p></div><div class="modal-body"><div class="detail-grid"><section class="detail-box"><h3>Čemu služi?</h3><p>${esc(m.purpose)}</p></section><section class="detail-box"><h3>Šta dobijate?</h3><ul>${m.gains.map(g=>`<li>${esc(g)}</li>`).join('')}</ul></section></div><div class="benefits">${benefits}</div><section class="example"><h3>Kako izgleda u praksi</h3><p>${esc(m.example)}</p></section>${gallery}${video}<div class="modal-actions"><a class="btn red" href="mailto:podrska@octopos.rs?subject=${encodeURIComponent('Upit za Octopos modul: '+m.title)}">Zatražite aktivaciju <span aria-hidden="true">↗</span></a><button type="button" class="btn ghost" id="modal-back">Nazad na module</button></div></div>`;
modal.classList.add('open');modal.setAttribute('aria-hidden','false');document.body.style.overflow='hidden';document.getElementById('modal-close').focus();
document.getElementById('modal-back').onclick=closeModule;
}
function closeModule(){modal.classList.remove('open');modal.setAttribute('aria-hidden','true');document.body.style.overflow='';lastFocus?.focus()}
document.getElementById('modal-close').addEventListener('click',closeModule);
modal.addEventListener('click',e=>{if(e.target===modal)closeModule()});
const lightbox=document.getElementById('lightbox');
modalContent.addEventListener('click',e=>{const b=e.target.closest('[data-image]');if(b){document.getElementById('large-image').src=b.dataset.image;lightbox.classList.add('open');lightbox.setAttribute('aria-hidden','false')}});
function closeLightbox(){lightbox.classList.remove('open');lightbox.setAttribute('aria-hidden','true');document.getElementById('large-image').src=''}
document.getElementById('lightbox-close').onclick=closeLightbox;
lightbox.addEventListener('click',e=>{if(e.target===lightbox)closeLightbox()});
document.addEventListener('keydown',e=>{if(e.key==='Escape'){if(lightbox.classList.contains('open'))closeLightbox();else if(modal.classList.contains('open'))closeModule()}});
render();
document.querySelectorAll('.reveal').forEach(el=>observer.observe(el));
